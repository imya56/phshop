<?php

namespace App\Http\Controllers;

use App\Content;
use App\Product;
use DB;
use Illuminate\Http\Request;

class PagesController extends MainController
{

    public function home()
    {
        self::$data['pageTitle'] .= 'Home Page';
        Product::homePage(self::$data);
        return view('content.home', self::$data);

    }

    public function content($url)
    {
        # dd(self::$data);
        Content::getAll($url, self::$data);
        return view('content.content', self::$data);
    }



}