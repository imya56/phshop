<?php

namespace App\Http\Controllers;

use App\Http\Requests\SigninRequest;
use App\Http\Requests\SignupRequest;
use App\Product;
use App\User;
use DB;
use Illuminate\Http\Request;
use Session;

class UserController extends MainController
{

    public function __construct()
    {
        parent::__construct();
        $this->middleware('authuser', ['except' => ['logout', 'wishlist', 'deleteWishlist', 'products', 'item']]);
    }

    public function getSignin()
    {

        self::$data['pageTitle'] .= 'Signin';
        return view('forms.signin', self::$data);

    }

    public function postSignin(SigninRequest $request)
    {

        if (User::authUser($request['email'], $request['password'])) {
            $rm = !empty($request['rn']) ? $request['rn'] : '/';
            return redirect($rm);
        } else {
            self::$data['pageTitle'] .= 'signin page';
            self::$data['authError'] = 'Wrong email or password';
            return view('forms.signin', self::$data);
        }
    }

    public function logout()
    {
        Session::flush();
        return redirect('user/signin');
    }

    public function getSignup()
    {
        self::$data['pageTitle'] .= 'Signup page';
        self::$data['errors_top'] = false;
        return view('forms.signup', self::$data);
    }
    public function postSignup(SignupRequest $request)
    {

        User::save_new($request);
        return redirect('/');

    }

    # Wish list #

    public function wishlist()
    {
        Product::wishlist(self::$data);
        return view('user.wishlist', self::$data);
    }

    public function deleteWishlist(Request $request)
    {

        $uid = Session::get('user_id');

        $pid = $request['pid'];
        DB::table('wishlists')->where([
            ['user_id', '=', $uid],
            ['product_id', '=', $pid],
        ])->delete();

        return redirect('/user/wishlist');
    }

    public function products($curl)
    {

        Product::getProducts($curl, self::$data);
        User::getLikes(self::$data);

        return view('content.products', self::$data);

    }

    public function item($curl, $purl)
    {

        Product::getProduct($purl, self::$data);
        User::getLikes(self::$data);
        return view('content.item', self::$data);
    }

}