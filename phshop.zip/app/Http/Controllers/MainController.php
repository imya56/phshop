<?php

namespace App\Http\Controllers;

use App\Categorie;
use App\Menu;
use App\Product;
use Cookie;

class MainController extends Controller
{

    public static $data = [
        'pageTitle' => 'PhShop | ',
        'errors_top' => true,

    ];

    public function __construct()
    {
        Product::wishlist(self::$data);
        self::$data['cat'] = Cookie::has('cat') ? Cookie::get('cat') : '';
        self::$data['menu'] = Menu::all()->toArray();
        self::$data['categories'] = Categorie::all()->toArray();

    }
}