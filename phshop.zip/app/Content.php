<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;
use Session;

class Content extends Model
{
    public static function getAll($url, &$data) {
        $content = DB::table('contents AS c')
            -> join('menus AS m', 'm.id', '=', 'c.menu_id')
            -> where('m.url', '=', $url)
            -> select('m.title AS mtitle', 'c.*')
            -> get()
            -> toArray();

            if(! $content) {
               
                abort(404);
            } else {
                $data['pageTitle'] = $content[0] -> title;
                $data['content'] = $content;
            }
    }

    static public function save_new($request)
    {
        $content = new self;
        $content -> menu_id = $request['menu_id'];
        $content -> title = $request['title'];
        $content -> article = $request['article'];
        $content -> save();
        Session::flash('tosterPos', 'toast-top-full-width');
        Session::flash('tosterPos', 'toast-top-center');
        Session::flash('sm', 'Content saved');
    }
    public static function update_item($request, $id){
        $content =self::find($id);
        $content -> menu_id = $request['menu_id'];
        $content -> title = $request['title'];
        $content -> article = $request['article'];
        $content -> save();
        Session::flash('tosterPos', 'toast-top-full-width');
        Session::flash('tosterPos', 'toast-top-center');
        Session::flash('sm', 'Content updated');
    }
}