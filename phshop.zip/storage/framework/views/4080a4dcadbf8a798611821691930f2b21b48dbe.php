<?php $__env->startSection('main_content'); ?>
<!--
*************
pages istory
*************
-->
<div class="osahan-breadcrumb">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>"><i class="icofont icofont-ui-home"></i> Home</a></li>
                    <li class="breadcrumb-item"><a href=" <?php echo e(url('shop')); ?> ">Categories</a></li>
                    <li class="breadcrumb-item active"><?php echo e(ucfirst( $products[0]->curl )); ?></li>
                </ol>
            </div>
        </div>
    </div>
</div>
<section class="products_page">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12">
                <div class="row products_page_list">
                    <div class="clearfix"></div>
                    <!--************************************** PRODUCT ***************************** -->
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-6 col-md-6">
                        <div class="item">
                            <div class="h-100">
                                <div class="product-item product-item-list">
                                    <?php if($product->onSale): ?>
                                    <span class="badge badge-warning offer-badge">On Sale!</span> <?php endif; ?>
                                    <div class="product-item-image">
                                        <a href="<?php echo e(url('shop/' . $product->curl . '/' . $product->purl)); ?>">
                                            <img class="card-img-top img-fluid" src="<?php echo e(asset('images') . '/' . $product -> pimage); ?>" alt="<?php echo e($product->ptitle); ?> product image">
                                        </a>
                                    </div>
                                    <div class="product-item-body">
                                        <h4 class="card-title"><a href="<?php echo e(url('shop/' . $product->curl . '/' . $product->purl)); ?>"><?php echo e($product->ptitle); ?></a></h4>
                                        <?php if($product -> onSale): ?>
                                        <p>

                                            <span class="product-desc-price"> $<?php echo e($product->price); ?></span>
                                            <span class="product-price"><b> $<?php echo e($product->new_price); ?></b></span>
                                        </p>
                                        <?php else: ?>
                                        <p class="d-inline">
                                            <span class="product-price"> $<?php echo e($product->price); ?> </span>
                                        </p>
                                        <?php endif; ?>

                                    </div>

                                    <div class="list-product-item-action">
                                        <a class="btn btn-theme-round mt-5" href="<?php echo e(url('shop/' . $product->curl . '/' . $product->purl)); ?>"><i class="icofont icofont-search-alt-2"></i> View details</a>                                        <?php if(!Cart::get($product->id)): ?>

                                        <button class="btn btn-theme-round mt-5  btn-add-to-cart" data-id="<?php echo e($product -> id); ?>"><i class="icofont icofont-shopping-cart"></i> Add To Cart</button>                                        <?php else: ?>
                                        <button class="btn btn-theme-round mt-5  btn-add-to-cart" data-id="<?php echo e($product -> id); ?>" disabled="disabled"><i class="icofont icofont-shopping-cart"></i>In Cart</button>                                        <?php endif; ?> <?php if(Session::has('user_id')): ?> <?php if(in_Array($product->id, $likes)): ?>
                                        <a data-toggle="tooltip" data-placement="top" data-id="<?php echo e($product -> id); ?>" class="btn btn-danger mt-5  save-in-wishlist disabled"
                                            href="" data-original-title="SAVED"><i class="icofont icofont-heart"></i></a>                                        <?php else: ?>
                                        <a data-toggle="tooltip" data-placement="top" data-id="<?php echo e($product -> id); ?>" class="btn btn-danger mt-5  save-in-wishlist"
                                            href="" data-original-title="SAVE"><i class="icofont icofont-heart"></i></a>                                        <?php endif; ?> <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <!--************************************** END PRODUCT ***************************** -->


                </div>
                <?php echo e($products->links()); ?>

            </div>
        </div>
        </section
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>