<?php $__env->startSection('main_cms_content'); ?>
<div class=" d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 ">
    <h1 class="h1 ">View Site Orders</h1>
</div>
<div class="row">
    <div class="col-11 mt-5">
        <table class="table table-striped mb-5">
            <thead>
                <tr>
                    <th>User</th>
                    <th>Total</th>
                    <th>Details</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->name); ?></td>
                    <td>$<?php echo e($item->total); ?> </td>
                    <td>
                        <ul>
                            <?php $__currentLoopData = unserialize($item->data); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($order['name']); ?>, price item: $<?php echo e($order['price']); ?>, Quantity: <?php echo e($order['quantity']); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </td>
                    <td><?php echo e(date('d/m/Y', strtotime($item->created_at))); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>