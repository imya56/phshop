<link rel="icon" type="image/png') }}" href="<?php echo e(asset('template/images/favicon.png')); ?>">
<!-- Bootstrap core CSS -->
<link href="<?php echo e(asset('template/css/bootstrap.min.css')); ?>" rel="stylesheet">
<!-- Custom styles for this template -->
<link href="<?php echo e(asset('template/css/style.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('template/css/animate.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('template/css/mobile.css')); ?>" rel="stylesheet">
<!-- Font Icons -->
<link href="<?php echo e(asset('template/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('template/css/icofont.css')); ?>" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ"
    crossorigin="anonymous">
<!-- Owl Carousel -->
<link rel="stylesheet" href="<?php echo e(asset('template/plugins/owl-carousel/owl.carousel.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('template/plugins/owl-carousel/owl.theme.css')); ?>">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
<link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
