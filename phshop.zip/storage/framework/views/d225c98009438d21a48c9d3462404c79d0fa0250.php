<?php $__env->startSection('main_cms_content'); ?>
<div class="mt-5">

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>