<?php $__env->startSection('main_cms_content'); ?>

<div class="row">
    <div class="col-12 mt-5">
        <h1 class="h3">Are you sure you want to delete this item?</h1>
    </div>
</div>
<div class="row">
    <div class="col-6 m-auto   ">
        <form action=" <?php echo e(url('cms/menu/' . $item_id)); ?> " method="POST">
            <?php echo csrf_field(); ?> <?php echo e(method_field('DELETE')); ?>

            <input type="submit" class="btn btn-danger mr-2" name="submit" value="Delete">
            <a href="<?php echo e(url('cms/menu')); ?>" class="btn btn-secondary"> Cancel </a>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>