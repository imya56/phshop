<script src="<?php echo e(asset('template/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('template/js/popper.min.js')); ?>"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
<script src="<?php echo e(asset('template/plugins/tether/tether.min.js')); ?>"></script>
<script src="<?php echo e(asset('template/js/bootstrap.min.js')); ?>"></script>
<!-- Custom js -->
<script src="<?php echo e(asset('template/js/custom.js')); ?>"></script>
<!-- Select2 -->
<link href="<?php echo e(asset('template/plugins/select2/css/select2.min.css')); ?>" rel="stylesheet" />
<script src="<?php echo e(asset('template/plugins/select2/js/select2.min.js')); ?>"></script>
<!-- Owl Carousel -->
<script src="<?php echo e(asset('template/plugins/owl-carousel/owl.carousel.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<script src="<?php echo e(asset('js/script.js')); ?>"></script>
<?php if(Session::has('sm')): ?>
<script>
    toastr.options.timeOut = 1800;
    toastr.options.closeButton = true;
    toastr.options.progressBar = true;

    <?php if(Session::has('tosterPos')): ?>
    toastr.options.positionClass = "<?php echo e(Session::get('tosterPos')); ?>";
    <?php else: ?>
    toastr.options.positionClass = 'toast-bottom-full-width';
    <?php endif; ?>
    toastr.success("<?php echo e(Session::get('sm')); ?>");

</script>

<?php endif; ?>
