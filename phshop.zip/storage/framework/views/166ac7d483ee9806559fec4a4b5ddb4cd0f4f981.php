<?php $__env->startSection('main_content'); ?>
<section class="login_page">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-6 mx-auto">
                <div class="widget">
                    <div class="login-modal-right">
                        <!-- Tab panes -->
                        <div class="tab-content">
                            <div class="tab-pane active" id="register" role="tabpanel">
                                <h5 class="heading-design-h5">Register Now!</h5>
                                <form action="" novalidate="novalidate" autocomplete="off" method="POST" class="text-left">
                                    <?php echo csrf_field(); ?>
                                    <fieldset class="form-group">
                                        <label for="name"> <span class="text-danger">* </span> Name:</label>
                                        <input type="text" name="name" id="name" class="form-control" placeholder="my name">
                                        <span class="text-danger"> <?php echo e($errors -> first('name')); ?></span>
                                    </fieldset>
                                    <fieldset class="form-group">
                                        <label for="email"> <span class="text-danger">* </span> Enter Email: </label>
                                        <input type="email" id="email" name="email" class="form-control" placeholder="myemail@gmail.com ">
                                        <span class="text-danger">  <?php echo e($errors -> first('email')); ?></span>
                                    </fieldset>
                                    <fieldset class="form-group">
                                        <label for="password"> <span class="text-danger">* </span> Enter Password: </label>
                                        <input type="password" name="password" id="password" class="form-control" placeholder="********">
                                        <span class="text-danger"> <?php echo e($errors -> first('password')); ?></span>
                                    </fieldset>
                                    <fieldset class="form-group">
                                        <button type="submit" class="btn btn-lg btn-theme-round btn-block">Create Your Account</button>
                                    </fieldset>
                                </form>

                            </div>
                        </div>
                        <div class="clearfix"></div>
                        <div class="text-center login-footer-tab">
                            <ul class="nav nav-tabs" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(url('user/signin')); ?>"><i class="icofont icofont-lock"></i> LOGIN</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link active" href="<?php echo e(url('user/signup')); ?>"><i class="icofont icofont-pencil-alt-5"></i> REGISTER</a>
                                </li>
                            </ul>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>