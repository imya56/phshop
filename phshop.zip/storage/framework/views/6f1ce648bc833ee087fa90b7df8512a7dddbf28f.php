<?php $__env->startSection('main_cms_content'); ?>
<div class=" d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 ">
    <h1 class="h1 ">Add Product Form</h1>

</div>
<div class="row my-5">
    <div class="col-6 text-left">
        <p><a href="<?php echo e(url('cms/home-products')); ?>"><i class="fas fa-arrow-circle-left btn btn-primary " style="margin-left: 900px"> Back</i> </a></p>
        <form action="<?php echo e(url('cms/home-products')); ?>" enctype="multipart/form-data" method="POST" autocomplete="off" novalidate="novalidate">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="id"><span class="text-danger">*</span>Product</label>
                <select class="form-control" name="id" id="id">
          <option value="">Choose product...</option>
          <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option  value="<?php echo e($item['id']); ?>"><?php echo e($item['ptitle']); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
            </div>
            <div class="form-group">
                <label for="sel1">Select list:</label>
                <select class="form-control" name="position" id="sel1">
                <?php for($x = 1; $x<=9;$x++): ?>
                    <option value="<?php echo e($x); ?>"> <?php echo e($x); ?>

                 <?php endfor; ?> 
                </select>
            </div>
            <input type="submit" value="Save" name="submit" class="btn btn-primary btn-block mt-5">
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
           <div class=""> 
                <label for="index"> Product position <label>
                <select>
                 <?php for($x = 1; $x<=9;$x++): ?>
                    <option value="<?php echo e($x); ?>"> <?php echo e($x); ?>

                 <?php endfor; ?>
                </select>
            </div>
           
<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>