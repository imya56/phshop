<?php $__env->startSection('main_content'); ?>
<section class="category-page">
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-4 col-sm-4 categorie">
                <div class="widget">
                    <div class="categories-page-image ">
                        <a href=" <?php echo e(url('shop/' . $categorie['curl'])); ?>"><img class="img-fluid " src="<?php echo e(asset( 'images/' . $categorie[ 'cimage'])); ?>" alt="category image for <?php echo e($categorie['ctitle']); ?>" style="height:250px; "></a>
                    </div>
                    <div class="widget-header ">
                        <small>98,156 Items</small>
                        <a href=" <?php echo e(url('shop/' . $categorie['curl'])); ?>">
                            <h1><i class="icofont icofont-brand-android-robot "></i> <?php echo e($categorie['ctitle']); ?></h1>
                        </a>
                    </div>
                    <p><?php echo $categorie['carticle']; ?></p>

                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>