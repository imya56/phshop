<!doctype html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>phShop | Admin Panel</title>
    <?php echo $__env->make('inc.css_header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/dashboard.css')); ?>">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.11/summernote-bs4.css" rel="stylesheet">
    <style>
        ul,
        li,
        select,
        option,
        label {
            text-align: left;
        }
    </style>
</head>

<body>



    <nav class="navbar navbar-dark fixed-top bg-dark flex-md-nowrap pr-5 shadow">
        <a class="navbar-brand col-sm-3 col-md-2 mr-0" href="<?php echo e(asset('cms/dashboard')); ?>">phShop Admin Panel</a>

        <ul class=" nav  ">
            <li class="nav-item  ">
                <a class="nav-link text-white" target="_blank" href="<?php echo e(url('')); ?>">Back To Site</a>
            </li>
            <li class="nav-item  ">
                <a class="nav-link text-white" href="<?php echo e(url('user/logout')); ?>">Logout</a>
            </li>
        </ul>
    </nav>




    <div class="container-fluid">
        <div class="row">
            <nav class="col-md-2 d-none d-md-block bg-light sidebar">
                <div class="sidebar-sticky">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('cms/dashboard')); ?>">
                                    Dashboard
                             </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('cms/menu')); ?>">
                                    Menu
                             </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('cms/content')); ?>">
                                    Content
                             </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('cms/categories')); ?>">
                                    Categories
                             </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('cms/products')); ?>">
                                    Products
                             </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('cms/orders')); ?>">
                                    Orders
                             </a>
                        </li>
                    </ul>

                </div>
            </nav>

            <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
    <?php echo $__env->make('inc.error_mess', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>; <?php echo $__env->yieldContent('main_cms_content'); ?>
            </main>
        </div>
    </div>
    <?php echo $__env->make('inc.js_footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.11/summernote-bs4.js"></script>
    <script>
        $('#article').summernote({
             height: 300
            });
    </script>
</body>

</html>
