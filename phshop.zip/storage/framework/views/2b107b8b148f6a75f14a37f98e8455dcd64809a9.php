<?php $__env->startSection('main_content'); ?>

<section class="shopping_cart_page">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-8 mx-auto">
                <div class="widget">
                    <div class="section-header">
                        <h3 class="heading-design-h5">
                            Cart
                        </h3>
                    </div>
                    <?php if($cart): ?>
                    <div class="table-responsive">

                        <table class="table cart_summary">
                            <thead>
                                <tr>
                                    <th class="cart_product">Product</th>
                                    <th>Description</th>
                                    <th>Avail.</th>
                                    <th>Unit price</th>
                                    <th>Qty</th>
                                    <th>Total</th>
                                    <th class="action"><i class="fa fa-trash-o"></i></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="cart_product"><a href="#"><img class="img-fluid" src="<?php echo e(asset('images/' . $product['attributes']['image'])); ?>" alt="Product"></a></td>
                                    <td class="cart_description">
                                        <p class="product-name"><a href="#"><?php echo e($product['name']); ?></a></p>
                                        <small><a href="">Color : Red</a></small>
                                    </td>
                                    <td class="availability in-stock"><span class="badge badge-success">In stock</span></td>
                                    <td class="price"><span>$<?php echo e($product['price']); ?></span></td>
                                    <td class="qty">
                                        <div class="input-group">
                                            <span class="input-group-btn">
                                     <a href="<?php echo e(url('shop/update-cart?pid=' . $product['id'] . '&op=minus')); ?>" class="btn btn-theme-round btn-number btn-shop-item-count"><span class="fa fa-minus  "></span></a>

                                            </button>
                                            </span>
                                            <input class="form-control border-form-control form-control-sm input-number" value="<?php echo e($product['quantity']); ?>" type="text">
                                            <span class="input-group-btn">
                                      <a href="<?php echo e(url('shop/update-cart?pid=' . $product['id'] . '&op=plus')); ?>" class="btn btn-theme-round btn-number btn-shop-item-count" ><span class="fa fa-plus"></span></a>


                                            </button>
                                            </span>
                                        </div>
                                    </td>
                                    <td class="price"><span>$<?php echo e($product['price'] * $product['quantity']); ?></span></td>
                                    <td class="action">
                                        <a data-toggle="tooltip" data-placement="top" title="" href="<?php echo e(url('shop/remove-item?pid=' . $product['id'])); ?>" data-original-title="Remove"><i class="fa fa-trash-o"></i></a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot>

                                <tr>
                                    <td colspan="2"></td>
                                    <td colspan="3">Total products (tax incl.)</td>
                                    <td colspan="2">$437.88 </td>
                                </tr>
                                <tr>
                                    <td colspan="5"><strong>Total</strong></td>
                                    <td colspan="2"><strong>$<?php echo e(Cart::getTotal()); ?> </strong></td>
                                </tr>
                            </tfoot>
                        </table>

                    </div>
                    <a href="<?php echo e(url('shop/empty-cart')); ?>" class="btn float-left btn-danger mb-1">Clean all</a>
                    <a href="<?php echo e(url('shop/order')); ?>" class="btn btn-theme-round btn-lg pull-right">ORDER NOW</a>
                </div>
                <?php else: ?>
                <p class="text-center m-auto h4"> No products in cart</p>
            </div>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>