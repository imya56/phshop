<?php $__env->startSection('main_cms_content'); ?>

<div class="row">
    <div class="col-12 mt-5">
        <h1 class="h2">Edit Content Form</h1>
        <p class="mt-3"> <a href=" <?php echo e(url('cms/content/')); ?> " class="btn btn-primary"><i class="fas fa-arrow-circle-left"></i> Back  </a></p>
    </div>
</div>
<div class="row">
    <div class="col-6 m-auto   ">
        <form action=" <?php echo e(url('cms/content/' . $item['id'])); ?> " method="POST" autocomplete="off" novalidate="novalidate">
            <?php echo csrf_field(); ?> <?php echo e(method_field('PUT')); ?>

            <div class="form-group">
                <label for="menu-id">Choose link</label>
                <select name="menu_id" id="menu-id">
                    <option  value=""> Choose menu link...</option>
                    <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option <?php if($item['menu_id'] == $row['id']): ?>  selected="selected" <?php endif; ?> value="<?php echo e($row['id']); ?>"> <?php echo e($row['link']); ?> </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="title"> <span class="text-danger">*</span> Title </label>
                <input type="text" class="form-control" name="title" id="title" value=" <?php echo e($item['title']); ?> ">
            </div>
            <div class="form-group">
                <label for="artice"> <span class="text-danger"> * </span> Article </label>
                <textarea name="article" id="article" class="form-control"> <?php echo e($item['article']); ?> </textarea>
            </div>
            <div class="form-group">
                <input type="submit" value="Update" name="submit" class="form-control btn btn-primary btn-block">
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>