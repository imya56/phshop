<?php $__env->startSection('main_cms_content'); ?>
<div class=" d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center mt-5 pt-3 pb-2 mb-3 ">
    <h1 class="h1 ">Edit Product Form</h1>

</div>
<div class="row my-5">
    <div class="col-6 text-left">
        <p><a href="<?php echo e(url('cms/products')); ?>"><i   class="fas fa-arrow-circle-left btn btn-primary "> Back</i> </a></p>
        <form action="<?php echo e(url('cms/products/' . $item['id'])); ?>" enctype="multipart/form-data" method="POST" autocomplete="off" novalidate="novalidate">
            <input type="hidden" name="item_id" value="<?php echo e($item['id']); ?>"> <?php echo csrf_field(); ?> <?php echo e(method_field('PUT')); ?>

            <div class="form-group">
                <label for="categorie-id"><span class="text-danger">*</span>Category</label>
                <select class="form-control" name="categorie_id" id="categorie-id">

          <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option <?php if( $item['categorie_id'] == $row['id'] ): ?> selected="selected" <?php endif; ?> value="<?php echo e($row['id']); ?>"><?php echo e($row['ctitle']); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
            </div>
            <div class="form-group">
                <label for="title"><span class="text-danger">*</span>Title</label>
                <input value="<?php echo e($item['ptitle']); ?>" class="form-control origin-text" type="text" name="title" id="title">
            </div>
            <div class="form-group">
                <label for="url"><span class="text-danger">*</span>Url</label>
                <input value="<?php echo e($item['purl']); ?>" class="form-control target-text" type="text" name="url" id="url">
            </div>
            <div class="form-group">
                <label for="price"><span class="text-danger">*</span>Price</label>
                <input value="<?php echo e($item['price']); ?>" class="form-control " type="text" name="price" id="price">
            </div>
            <div class="form-group">
                <label for="article"><span class="text-danger">*</span> Article</label>
                <textarea name="article" id="article" class="form-control"><?php echo e($item['particle']); ?></textarea>
            </div>
            <div class="form-group">
                <span class="mr-3 float-left"> Category Image:  </span>
                <label class="custom-file" for="cat-img">
                        <input type="file" name="image" id="cat-img" class="custom-file-input">
                        <span class="custom-file-control"></span>
                    </label>
            </div>
            <input <?php if($item[ 'onSale']): ?> checked="checked" <?php endif; ?> type="checkbox" name="sale" id="sale" value="1"> On Sale
            <div class="price-on-sale   <?php if(!$item['onSale']): ?> d-none <?php endif; ?>">
                <div class="form-group">
                    <label for="old-price">Old price:</label>
                    <input type="text" name="old_price" id="old-price" class="" value="<?php echo e($item['price']); ?>" size="2">
                </div>
                <div class="form-group">
                    <label for="new-price">new price:</label>
                    <input type="text" name="new_price" id="new-price" value="<?php echo e($item['new_price'] ?? 0); ?>" size="2">
                </div>
            </div>
            <input type="submit" value="Update" name="submit" class="btn btn-primary btn-block mt-5">
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>