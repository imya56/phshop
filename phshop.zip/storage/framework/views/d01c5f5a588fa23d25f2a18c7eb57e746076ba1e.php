<?php $__env->startSection('main_content'); ?>
<section class="shopping_cart_page">
    <h6 class="sr-only">validator.w3</h6>
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-4 col-sm-5">
                <div class="user-account-sidebar">
                    <aside class="user-info-wrapper">
                        <div class="user-cover" style="background-image: url(<?php echo e(url('images/default.jpg')); ?>);">
                            <div class="info-label" data-toggle="tooltip" title="" data-original-title="Verified Account"><i class="icofont icofont-check-circled"></i></div>
                        </div>
                        <div class="user-info">

                        </div>
                    </aside>
                    <nav class="list-group">
                        <a class="list-group-item active justify-content-between" href="wishlist-user.html"><span><i class="icofont icofont-heart-alt fa-fw"></i> Wish List</span> </a>
                        <a class="list-group-item btn btn-danger" href="login.html"><i class="icofont icofont-logout fa-fw"></i> Logout</a>
                    </nav>
                </div>
            </div>
            <div class="col-lg-8 col-md-8 col-sm-7">
                <div class="widget">
                    <div class="section-header">
                        <h5 class="heading-design-h5">
                            My Wishlist
                        </h5>
                    </div>
                    <div class="row mb-4">

                        <?php $__currentLoopData = $wishProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 col-md-6">
                            <div class="h-100">
                                <div class="product-item">
                                    <div class="product-item-image">
                                        <span class="like-icon"><a href="<?php echo e(url('user/delwishlist?pid=' . $item[0]->id)); ?>"> <i class="icofont icofont-close-circled"></i></a></span>
                                        <a href="<?php echo e(url('shop/' . $item[0]->curl . '/' . $item[0]->purl)); ?>"><img class="card-img-top img-fluid" src=" <?php echo e(asset('images/' . $item[0]->pimage)); ?> " alt=""></a>
                                    </div>
                                    <div class="product-item-body">

                                        <p class="card-title"><a href="#"> <?php echo e($item[0]->ptitle); ?></a></p>
                                        <p>

                                            <span class="product-price"><?php echo e($item[0] -> price); ?></span>

                                        </p>
                                        <p>
                                            <?php if(! Cart::get($item[0] -> id)): ?>
                                            <button class="btn btn-theme-round btn-lg btn-add-to-cart" data-id="<?php echo e($item[0]->id); ?>"> <i class="icofont icofont-shopping-cart"></i> Add To Cart</button>                                            <?php else: ?>
                                            <button class="btn btn-theme-round btn-lg btn-add-to-cart" disabled="disabled"> <i class="icofont icofont-shopping-cart"></i> In Cart</button>                                            <?php endif; ?> </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>