<?php $__env->startSection('main_cms_content'); ?>

<div class="row">
    <div class="col-12 mt-5">
        <h1 class="h2">Edit Site Content</h1>
        <p class="mt-3"> <a href=" <?php echo e(url('cms/content/create')); ?> " class="btn btn-primary"><i class="fas fa-plus-circle"></i> Add Site Content </a></p>

        <div class="row">
            <div class="col-12">
                <table class="table table-striped mt-5">
                    <thead>
                        <tr>
                            <th> Title </th>
                            <th>Updated At</th>
                            <th> Operation </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td> <?php echo e($item['title']); ?> </td>
                            <td><?php echo e(date('d/m/Y', strtotime( $item['updated_at']))); ?></td>
                            <td>
                                <a href=" <?php echo e(url('cms/content/' . $item['id'] . '/edit')); ?> " class="mr-2"> <i class="fas fa-pencil-alt"></i> Edit  </a>                                |
                                <a href=" <?php echo e(url('cms/content/' . $item['id'])); ?> " class="ml-2"> <i class="fas fa-trash-alt"></i> Delete </a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>