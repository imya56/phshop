@extends('cms.cms_master')
@section('main_cms_content')
<div class=" d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 ">
    <h1 class="h1 ">View Site Orders</h1>
</div>
<div class="row">
    <div class="col-11 mt-5">
        <table class="table table-striped mb-5">
            <thead>
                <tr>
                    <th>User</th>
                    <th>Total</th>
                    <th>Details</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                @foreach($orders as $item)
                <tr>
                    <td>{{ $item->name }}</td>
                    <td>${{ $item->total }} </td>
                    <td>
                        <ul>
                            @foreach(unserialize($item->data) as $order)
                            <li>{{ $order['name'] }}, price item: ${{ $order['price'] }}, Quantity: {{ $order['quantity'] }}</li>
                            @endforeach
                        </ul>
                    </td>
                    <td>{{ date('d/m/Y', strtotime($item->created_at)) }}</td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>
@endsection
